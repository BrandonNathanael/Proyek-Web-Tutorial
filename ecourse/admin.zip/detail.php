<?php
session_start();
require_once 'config.php';

// Get course ID from URL
if (!isset($_GET['id'])) {
    header("Location: kursus.php");
    exit();
}

$course_id = (int)$_GET['id'];

// Fetch course details
$stmt = $conn->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();
$course = $result->fetch_assoc();

if (!$course) {
    header("Location: kursus.php");
    exit();
}

// Check if user has already purchased this course
$has_purchased = false;
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = ? AND course_id = ? AND payment_status = 'completed'");
    $stmt->bind_param("ii", $_SESSION['user_id'], $course_id);
    $stmt->execute();
    $has_purchased = $stmt->get_result()->num_rows > 0;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($course['title']); ?> - Detail Kursus</title>
    <link rel="icon" type="image/png" href="assets/logofull.svg" />
    <link rel="stylesheet" href="detail.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
</head>

<body>
    <!-- Header -->
    <header>
        <div class="logo">
            <a href="home.php">
                <img src="assets/elogo.svg" alt="Logo">
            </a>
        </div>
        <nav>
            <a href="home.php">Beranda</a>
            <a href="kursus.php" class="active">Cari Kursus</a>
            <a href="my-courses.php">Aktivitas</a>
        </nav>
        <div class="right-menu">
            <a href="transaction-history.php"><i class="fa fa-shopping-basket"></i></a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profil.php" class="profile-link">
                    <i class="fa fa-user"></i> <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                </a>
            <?php else: ?>
                <a href="login.php" class="profile-link">
                    <i class="fa fa-sign-in-alt"></i> <span>Masuk</span>
                </a>
            <?php endif; ?>
        </div>
    </header>

    <!-- Detail Konten -->
    <main class="course-detail">
        <section class="course-header">
            <div class="title-video-wrapper">
                <div class="title">
                    <h1><?php echo nl2br(htmlspecialchars($course['title'])); ?></h1>
                </div>
                <div class="video-intro">
                    <?php if ($has_purchased): ?>
                        <video controls width="100%" height="auto" poster="<?php echo htmlspecialchars($course['image_path']); ?>">
                            <source src="assets/introduction.mp4" type="video/mp4">
                            Browser Anda tidak mendukung video ini.
                        </video>
                    <?php else: ?>
                        <img src="<?php echo htmlspecialchars($course['image_path']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>" style="width: 100%; height: auto;">
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <section class="course-description">
            <h2>Deskripsi:</h2>
            <p><?php echo nl2br(htmlspecialchars($course['description'])); ?></p>

            <div class="price-info">
                <h3>Harga:</h3>
                <p class="price">Rp <?php echo number_format($course['price'], 0, ',', '.'); ?></p>
            </div>

            <div class="cta-button">
                <?php if ($has_purchased): ?>
                    <a href="course-content.php?id=<?php echo $course_id; ?>" class="buy-button">Akses Kursus</a>
                <?php elseif (isset($_SESSION['user_id'])): ?>
                    <a href="payment.php?course_id=<?php echo $course_id; ?>" class="buy-button">Beli Kursus</a>
                <?php else: ?>
                    <a href="login.php?redirect=detail.php?id=<?php echo $course_id; ?>" class="buy-button">Login untuk Membeli</a>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="footer-content">
            <p>&copy; 2025 E-Course. Semua Hak Dilindungi.</p>
            <p>Dibuat dengan ❤️ oleh Tim E-Course</p>
        </div>
    </footer>
</body>

</html> 