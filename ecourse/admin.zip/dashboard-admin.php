<?php
session_start();
require_once 'config.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$totalCourses = 0;
$totalUsers = 0;
$totalRevenue = 0;
$recentTransactions = null;
$error = null;

// Debug function
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);

    echo "<script>console.log('Debug: " . addslashes($output) . "');</script>";
}

// Fetch summary data
try {
    // Get total courses
    $result = $conn->query("SELECT COUNT(*) as total FROM courses");
    if ($result && $row = $result->fetch_assoc()) {
        $totalCourses = $row['total'];
        debug_to_console("Total Courses: " . $totalCourses);
        $result->free();
    }

    // Get total users
    $result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'user'");
    if ($result && $row = $result->fetch_assoc()) {
        $totalUsers = $row['total'];
        debug_to_console("Total Users: " . $totalUsers);
        $result->free();
    }

    // Get total revenue from completed transactions
    $revenueQuery = "SELECT SUM(amount) as total FROM transactions WHERE payment_status = 'completed'";
    debug_to_console("Revenue Query: " . $revenueQuery);
    $result = $conn->query($revenueQuery);
    if ($result && $row = $result->fetch_assoc()) {
        $totalRevenue = $row['total'] ?? 0;
        debug_to_console("Total Revenue: " . $totalRevenue);
        $result->free();
    }

    // Get recent transactions with user and course details
    $recentTransactionsQuery = "
        SELECT t.*, u.username, c.title as course_title 
        FROM transactions t 
        LEFT JOIN users u ON t.user_id = u.id 
        LEFT JOIN courses c ON t.course_id = c.id 
        ORDER BY t.transaction_date DESC 
        LIMIT 5
    ";
    debug_to_console("Recent Transactions Query: " . $recentTransactionsQuery);
    
    $recentTransactions = $conn->query($recentTransactionsQuery);
    if (!$recentTransactions) {
        throw new Exception("Error fetching recent transactions: " . $conn->error);
    } else {
        debug_to_console("Recent Transactions Count: " . $recentTransactions->num_rows);
    }

    // Get monthly revenue data for chart
    $monthlyRevenue = [];
    $monthlyRevenueQuery = "
        SELECT 
            DATE_FORMAT(transaction_date, '%Y-%m') as month,
            SUM(amount) as total
        FROM transactions 
        WHERE payment_status = 'completed'
            AND transaction_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(transaction_date, '%Y-%m')
        ORDER BY month ASC
    ";
    
    // Debug monthly revenue query
    error_log("Monthly Revenue Query: " . $monthlyRevenueQuery);
    
    $result = $conn->query($monthlyRevenueQuery);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $monthlyRevenue[$row['month']] = $row['total'];
            // Debug monthly revenue data
            error_log("Month: " . $row['month'] . ", Revenue: " . $row['total']);
        }
        $result->free();
    }

} catch(Exception $e) {
    $error = "Error fetching summary data: " . $e->getMessage();
}

// Format monthly data for chart
$labels = [];
$data = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i month"));
    $labels[] = date('M Y', strtotime($month));
    $data[] = isset($monthlyRevenue[$month]) ? (int)$monthlyRevenue[$month] : 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - E-Course</title>
    <link rel="icon" type="image/png" href="assets/logofull.svg" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="admin.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        .chart-container {
            position: relative;
            height: 400px;
            width: 100%;
            margin-top: 20px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .content-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px 0;
        }

        .table-responsive {
            overflow-x: auto;
            margin-top: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }

        th {
            background-color: #f8f9fa;
            font-weight: 600;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
        }

        .status-pending {
            background-color: #ffc107;
            color: #000;
        }

        .status-completed {
            background-color: #28a745;
            color: #fff;
        }

        .status-failed {
            background-color: #dc3545;
            color: #fff;
        }

        .status-refunded {
            background-color: #6c757d;
            color: #fff;
        }

        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .summary-card i {
            font-size: 24px;
            color: #007bff;
            background: rgba(0,123,255,0.1);
            padding: 15px;
            border-radius: 8px;
        }

        .card-info h3 {
            font-size: 24px;
            margin-bottom: 5px;
        }

        .card-info p {
            color: #6c757d;
            margin: 0;
        }

        @media (max-width: 768px) {
            .summary-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="assets/logofull.svg" alt="E-Course Logo">
            <span>E-Course Admin</span>
        </div>
        <ul class="nav-menu">
            <li>
                <a href="dashboard-admin.php" class="nav-item active">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="manage-courses.php" class="nav-item">
                    <i class="fas fa-book"></i>
                    <span>Kelola Kursus</span>
                </a>
            </li>
            <li>
                <a href="manage-users.php" class="nav-item">
                    <i class="fas fa-users"></i>
                    <span>Kelola Pengguna</span>
                </a>
            </li>
            <li>
                <a href="transactions.php" class="nav-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Transaksi</span>
                </a>
            </li>
            <li>
                <a href="materials.php" class="nav-item">
                    <i class="fas fa-file-alt"></i>
                    <span>Materi</span>
                </a>
            </li>
            <li>
                <a href="logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Keluar</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Dashboard Admin</h1>
            <div class="header-right">
                <div class="admin-profile">
                    <a href="admin-profile.php" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 10px;">
                        <img src="<?php echo htmlspecialchars($_SESSION['profile_photo'] ?? 'assets/default-avatar.png'); ?>" alt="Admin Avatar">
                        <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    </a>
                </div>
            </div>
        </div>

        <div class="summary-cards">
            <div class="summary-card">
                <i class="fas fa-book"></i>
                <div class="card-info">
                    <h3><?php echo number_format($totalCourses); ?></h3>
                    <p>Total Kursus</p>
                </div>
            </div>
            <div class="summary-card">
                <i class="fas fa-users"></i>
                <div class="card-info">
                    <h3><?php echo number_format($totalUsers); ?></h3>
                    <p>Total Pengguna</p>
                </div>
            </div>
            <div class="summary-card">
                <i class="fas fa-money-bill-wave"></i>
                <div class="card-info">
                    <h3>Rp <?php echo number_format($totalRevenue, 0, ',', '.'); ?></h3>
                    <p>Total Pendapatan</p>
                </div>
            </div>
        </div>

        <div class="content-card">
            <h2>Transaksi Terbaru</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID Transaksi</th>
                            <th>Pengguna</th>
                            <th>Kursus</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recentTransactions && $recentTransactions->num_rows > 0): ?>
                            <?php while($transaction = $recentTransactions->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $transaction['id']; ?></td>
                                    <td><?php echo htmlspecialchars($transaction['username'] ?? 'User Dihapus'); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['course_title'] ?? 'Kursus Dihapus'); ?></td>
                                    <td>Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($transaction['payment_status']); ?>">
                                            <?php echo ucfirst($transaction['payment_status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d M Y', strtotime($transaction['transaction_date'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                            <?php $recentTransactions->free(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada transaksi terbaru</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="chart-container">
            <h2>Grafik Pendapatan 6 Bulan Terakhir</h2>
            <canvas id="revenueChart"></canvas>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Auto refresh setiap 30 detik
        setInterval(function() {
            location.reload();
        }, 30000);

        // Inisialisasi grafik pendapatan
        const ctx = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    label: 'Pendapatan Bulanan',
                    data: <?php echo json_encode($data); ?>,
                    borderColor: '#007bff',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Pendapatan Bulanan (dalam Rupiah)'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + new Intl.NumberFormat('id-ID').format(value);
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html> 