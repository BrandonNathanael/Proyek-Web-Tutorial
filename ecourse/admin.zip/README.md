# project-ecommerce
Repository ini berisi kode sumber untuk frontend platform e-commerce kursus online berbasis web. Platform ini memungkinkan pengguna untuk mencari, membeli, dan mengikuti kursus secara digital dengan sistem pembayaran yang terintegrasi.
