ALTER TABLE transactions
ADD COLUMN payment_proof VARCHAR(255) AFTER amount; 