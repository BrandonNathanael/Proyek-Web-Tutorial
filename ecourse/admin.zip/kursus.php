<?php
session_start();
require_once 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Ambil data kursus dari database
$query = "SELECT * FROM courses";
if (isset($_GET['search'])) {
    $search = "%" . $_GET['search'] . "%";
    $query = "SELECT * FROM courses WHERE title LIKE ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cari Kursus - E-Course</title>
    <link rel="icon" type="image/png" href="assets/logofull.svg" />
    <link rel="stylesheet" href="kursus.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
</head>

<body>
    <header>
        <div class="logo">
            <a href="home.php">
                <img src="assets/elogo.svg" alt="Logo">
            </a>
        </div>
        <nav>
            <a href="home.php">Beranda</a>
            <a href="kursus.php" class="active">Cari Kursus</a>
            <a href="my-courses.php">Kursus Saya</a>
        </nav>
        <div class="right-menu">
            <a href="transaction-history.php"><i class="fa fa-shopping-basket"></i></a>
            <a href="profil.php" class="profile-link">
                <i class="fa fa-user"></i> <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
            </a>
        </div>
    </header>

    <section class="popular-courses">
        <h2 class="section-title">Cari Kursus</h2>
        <div style="width: 100%; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
            <div style="display: flex; justify-content: center; align-items: center; position: relative; margin: 30px 0;">
                <form method="GET" action="" style="width: 100%; max-width: 600px; position: relative;">
                    <div style="position: relative; display: flex; align-items: center;">
                        <i class="fa fa-search" style="position: absolute; left: 20px; color: #666; font-size: 18px;"></i>
                        <input type="text" 
                               name="search" 
                               id="searchInput" 
                               placeholder="Cari kursus yang ingin Anda pelajari..." 
                               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>"
                               style="width: 100%; height: 50px; padding: 0 50px; font-size: 16px; border: 2px solid #e0e0e0; border-radius: 25px; background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: all 0.3s ease;"
                               autocomplete="off">
                    </div>
                </form>
            </div>
        </div>
        
        <div style="width: 1200px; margin: 0 auto;">
            <div class="course-container">
                <?php
                if ($result->num_rows > 0) {
                    while ($course = $result->fetch_assoc()) {
                        // Cek apakah kursus sudah dibeli
                        $check_purchase = $conn->prepare("SELECT * FROM transactions WHERE user_id = ? AND course_id = ? AND payment_status = 'completed'");
                        $check_purchase->bind_param("ii", $_SESSION['user_id'], $course['id']);
                        $check_purchase->execute();
                        $is_purchased = $check_purchase->get_result()->num_rows > 0;
                ?>
                    <div class="course-card">
                        <img src="<?php echo htmlspecialchars($course['image_path']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>">
                        <h3><?php echo htmlspecialchars($course['title']); ?></h3>
                        <div class="stars">★★★★★</div>
                        <p class="price">Rp. <?php echo number_format($course['price'], 0, ',', '.'); ?></p>
                        <div class="card-footer">
                            <?php if ($is_purchased): ?>
                                <a href="course-content.php?id=<?php echo $course['id']; ?>" class="detail-btn">Lihat Materi</a>
                            <?php else: ?>
                                <a href="detail.php?id=<?php echo $course['id']; ?>" class="detail-btn">Detail Kursus</a>
                                <a href="transaction-history.php?add=<?php echo $course['id']; ?>" class="cart-icon">
                                    <i class="fa fa-shopping-basket"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php
                    }
                } else {
                    echo '<p class="no-courses">Tidak ada kursus yang ditemukan.</p>';
                }
                ?>
            </div>
        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-content">
            <p>&copy; 2025 E-Course. Semua Hak Dilindungi.</p>
            <p>Dibuat dengan ❤️ oleh Tim E-Course</p>
        </div>
    </footer>

</body>
</html> 